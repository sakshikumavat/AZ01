import Layout from '../components/Layout';

export default function Projects() {
  const projects = [
    {
      title: 'Small Shop Site',
      description:
        'A minimal e-commerce site for a local handmade business. Fast, clean, and easy to update.',
      tech: 'React, Tailwind, Stripe',
      link: '#',
    },
    {
      title: 'Personal Blog',
      description:
        "A writer's blog focused on content. No distractions, no ads, no tracking. Just good writing.",
      tech: 'Next.js, Markdown, Vercel',
      link: '#',
    },
    {
      title: 'Portfolio Page',
      description:
        "Photographer's portfolio showcasing work with beautiful, simple image galleries.",
      tech: 'React, Image Optimization',
      link: '#',
    },
    {
      title: 'Notes App',
      description:
        'Simple note-taking tool. Local storage, no account needed. Privacy first.',
      tech: 'React, LocalStorage',
      link: '#',
    },
    {
      title: 'Community Directory',
      description:
        'Local business directory built for a small town. Easy to search, easy to update.',
      tech: 'React, Database, Maps',
      link: '#',
    },
    {
      title: 'Documentation Site',
      description:
        'Clean documentation for an open-source project. Searchable, well-organized, fast.',
      tech: 'Next.js, MDX, Algolia',
      link: '#',
    },
  ];

  return (
    <Layout>
      <div className="space-y-12 py-12">
        <section className="space-y-4">
          <h1 className="text-4xl font-serif font-bold text-white">
            Projects
          </h1>
          <p className="text-gray-300 max-w-2xl">
            A collection of small, focused projects. Each one solves a real
            problem with simple, maintainable code.
          </p>
        </section>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {projects.map((p, i) => (
            <div
              key={i}
              className="border border-gray-800 rounded-lg p-6 space-y-4 hover:shadow-md hover:border-teal-600 transition"
            >
              <h3 className="text-xl font-semibold text-white">
                {p.title}
              </h3>
              <p className="text-gray-300 leading-relaxed">{p.description}</p>

              <div className="space-y-2">
                <p className="text-sm text-gray-400">Tech Stack</p>
                <p className="text-sm text-gray-400">{p.tech}</p>
              </div>

              <a
                href={p.link}
                className="inline-block text-teal-400 font-medium hover:text-teal-300 hover:underline mt-2"
              >
                View Project →
              </a>
            </div>
          ))}
        </div>
      </div>
    </Layout>
  );
}
