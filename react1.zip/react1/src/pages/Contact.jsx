import { useState } from 'react';
import Layout from '../components/Layout';

export default function Contact() {
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });
  const [submitted, setSubmitted] = useState(false);

  function handleChange(e) {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  }

  function handleSubmit(e) {
    e.preventDefault();
    console.log('contact:', formData);
    setSubmitted(true);
    setFormData({ name: '', email: '', subject: '', message: '' });
    setTimeout(() => setSubmitted(false), 4000);
  }

  return (
    <Layout>
      <div className="space-y-12 py-12">
        <section className="space-y-4">
          <h1 className="text-4xl font-serif font-bold text-white">Get in Touch</h1>
          <p className="text-gray-300 max-w-2xl">Have a question or project in mind? Send us a message. We read everything and reply when we can.</p>
        </section>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <div className="space-y-2">
            <div className="text-2xl">📧</div>
            <h3 className="font-semibold text-white">Email</h3>
            <p className="text-gray-400 text-sm">hello@handmadesite.com</p>
          </div>
          <div className="space-y-2">
            <div className="text-2xl">💬</div>
            <h3 className="font-semibold text-white">Chat</h3>
            <p className="text-gray-400 text-sm">Available via contact form</p>
          </div>
          <div className="space-y-2">
            <div className="text-2xl">⏱️</div>
            <h3 className="font-semibold text-white">Response</h3>
            <p className="text-gray-400 text-sm">Within 24 hours</p>
          </div>
        </div>

        <div className="max-w-2xl">
          {submitted && (
            <div className="mb-6 p-4 bg-teal-900 border border-teal-700 rounded text-teal-100">
              ✓ Thank you! We've received your message and will get back to you soon.
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-white">Your Name</label>
                <input
                  required
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full border border-gray-700 bg-gray-900 text-white rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-teal-600 focus:border-transparent"
                  placeholder="John Doe"
                />
              </div>
              <div className="space-y-2">
                <label className="block text-sm font-medium text-white">Email Address</label>
                <input
                  required
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full border border-gray-700 bg-gray-900 text-white rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-teal-600 focus:border-transparent"
                  placeholder="john@example.com"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-white">Subject</label>
              <input
                required
                name="subject"
                value={formData.subject}
                onChange={handleChange}
                className="w-full border border-gray-700 bg-gray-900 text-white rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-teal-600 focus:border-transparent"
                placeholder="What is this about?"
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-white">Message</label>
              <textarea
                required
                name="message"
                value={formData.message}
                onChange={handleChange}
                rows="6"
                className="w-full border border-gray-700 bg-gray-900 text-white rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-teal-600 focus:border-transparent"
                placeholder="Tell us about your project or question..."
              ></textarea>
            </div>

            <button
              type="submit"
              className="w-full bg-teal-600 text-white font-medium py-3 rounded hover:bg-teal-700 transition"
            >
              Send Message
            </button>
          </form>
        </div>
      </div>
    </Layout>
  );
}