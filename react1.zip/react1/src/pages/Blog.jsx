import Layout from '../components/Layout';

export default function Blog() {
  const posts = [
    {
      id: 1,
      title: 'The Power of Simplicity',
      date: 'November 14, 2025',
      author: 'Sarah Chen',
      image: 'https://images.unsplash.com/photo-1499750310107-5fef28a66643?w=600&h=400&fit=crop',
      excerpt: 'Why keeping things simple in design leads to better products and happier users.',
      content: `Simple design isn't about removing features. It's about removing complexity. When you strip away everything that isn't essential, what remains is powerful.

Think about the products you love. Chances are, they work because they do one thing really well. A good pencil. A comfortable chair. A well-designed door handle.

In web design, simplicity means your users understand what to do without thinking. They don't need instructions. The design teaches itself. This reduces friction, lowers bounce rates, and creates loyal users.

Start by asking: "What does this page need to do?" Then remove everything else. Your users will thank you.`
    },
    {
      id: 2,
      title: 'Design Principles That Matter',
      date: 'November 8, 2025',
      author: 'Marcus Johnson',
      image: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=600&h=400&fit=crop',
      excerpt: 'Four timeless design principles that never go out of style.',
      content: `Design trends come and go, but some principles remain constant. These are the ideas that separate good design from great design.

1. Consistency — Users learn how your site works by exploring. If buttons look the same, they expect them to act the same. Keep it predictable.

2. Contrast — Don't make users squint. Use clear contrast between text and background. Make important things stand out.

3. Hierarchy — Not all information is equal. Headings should look like headings. Small text should look like details. Guide the eye.

4. White Space — Empty space isn't wasted space. It gives the eye a place to rest. It makes content easier to read. Embrace it.

These four ideas can transform any design. Start with these and everything else follows.`
    },
    {
      id: 3,
      title: 'Building with React: Getting Started',
      date: 'November 1, 2025',
      author: 'Emma Rodriguez',
      image: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=600&h=400&fit=crop',
      excerpt: 'A beginner-friendly guide to building your first React component.',
      content: `React changes how you think about building interfaces. Instead of manipulating the DOM, you describe what the interface should look like. React handles the rest.

Components are the building blocks. A component is just a JavaScript function that returns JSX — HTML-like syntax that React understands.

Here's a simple component:

const Greeting = () => {
  return <h1>Hello, World!</h1>
}

See? It looks like HTML, but it's JavaScript. You can add logic, handle events, manage state — all inside this function.

The magic happens when your component needs to change. React watches your data. When data changes, React updates only the parts that changed. Your users see updates instantly, without page reloads.

That's why React powers so many modern websites. Start small. Build one component. Then build the next. Before you know it, you have a full application.`
    },
    {
      id: 4,
      title: 'The Art of Typography',
      date: 'October 25, 2025',
      author: 'David Kim',
      image: 'https://img.freepik.com/free-vector/flat-design-motivational-poster-illustration_52683-88764.jpg?semt=ais_hybrid&w=740&q=80',
      excerpt: 'How the right typeface can transform your design from ordinary to unforgettable.',
      content: `Typography is often overlooked, but it's one of the most powerful design tools you have. The right typeface can set the tone, establish hierarchy, and make content feel intentional.

Choose typefaces that match your message. A playful sans-serif works for a startup. A classic serif fits a law firm. Context matters.

But here's the hard part: most beginners use too many typefaces. Stick with two. One for headings, one for body text. This creates visual harmony.

Don't just pick a size and hope for the best. Line height should be 1.5 to 1.8 times the font size. This makes text easier to read. Line length should be 50-75 characters wide. Shorter lines are easier on the eyes.

Typography is invisible when it's right. You should notice the content, not the letters. When a user reads without effort, that's good typography at work.`
    },
    {
      id: 5,
      title: 'CSS Grid vs Flexbox: Which Should You Use?',
      date: 'October 18, 2025',
      author: 'Lisa Wang',
      image: 'https://miro.medium.com/1*iAa5UGWQfjFelBjBrh1sXA.png',
      excerpt: 'Understanding the differences and knowing when to reach for each tool.',
      content: `CSS Grid and Flexbox both layout content, but they solve different problems. Learning to use both makes you a better developer.

Flexbox is for one-dimensional layouts. It arranges items in a row or column. Use it for navigation menus, button groups, or content that flows in one direction.

Grid is for two-dimensional layouts. It arranges items in rows and columns simultaneously. Use it for page layouts, card grids, or complex compositions.

Here's a rule of thumb: if you're arranging items in a single line, use Flexbox. If you need control over both rows and columns, use Grid.

The good news? You can use both on the same page. Combine them. Use Grid for the page layout, then Flexbox inside Grid items. They work together beautifully.

Master both and you can build any layout you can imagine.`
    }
  ];

  return (
    <Layout>
      <section className="py-8">
        <h1 className="text-3xl font-semibold mb-2 text-white">Blog</h1>
        <p className="text-gray-300 mb-8">Thoughts on design, development, and building things that work.</p>

        <div className="space-y-12">
          {posts.map((post) => (
            <article key={post.id} className="border-b border-gray-800 pb-12">
              <div className="mb-4">
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full h-64 object-cover rounded"
                />
              </div>
              
              <div className="flex items-center gap-2 text-sm text-gray-400 mb-2">
                <span>{post.date}</span>
                <span>•</span>
                <span>By {post.author}</span>
              </div>

              <h2 className="text-2xl font-semibold mb-2 text-white">{post.title}</h2>
              <p className="text-gray-300 mb-4">{post.excerpt}</p>

              <div className="prose prose-sm max-w-none text-gray-300 whitespace-pre-wrap leading-relaxed">
                {post.content}
              </div>

              <div className="mt-6">
                <button className="text-teal-400 font-medium hover:text-teal-300 hover:underline">
                  Read full article →
                </button>
              </div>
            </article>
          ))}
        </div>
      </section>
    </Layout>
  );
}
