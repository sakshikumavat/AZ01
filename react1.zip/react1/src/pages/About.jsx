import Layout from '../components/Layout';

export default function About() {
  return (
    <Layout>
      <div className="space-y-12 py-12">
        <section className="space-y-6">
          <h1 className="text-4xl font-serif font-bold text-white">About This Site</h1>
          <div className="space-y-4 text-gray-300 leading-relaxed">
            <p>
              This is a handcrafted website. It's intentionally simple — no complex animations, no heavy images, no tracking scripts. Just clean code and clear content.
            </p>
            <p>
              We believe the best websites are the ones that get out of the way. They let your content shine. They load fast. They work on every device. They feel like someone built them with care.
            </p>
          </div>
        </section>

        {/* Values */}
        <section className="space-y-6">
          <h2 className="text-2xl font-semibold text-white">Our Values</h2>
          <div className="space-y-6">
            <div className="border-l-4 border-teal-600 pl-4 space-y-2">
              <h3 className="font-semibold text-white">Simplicity First</h3>
              <p className="text-gray-300">Remove everything that doesn't add value. Keep only what matters.</p>
            </div>
            <div className="border-l-4 border-teal-600 pl-4 space-y-2">
              <h3 className="font-semibold text-white">Clarity Over Cleverness</h3>
              <p className="text-gray-300">Write for your user. Not for yourself. Make understanding easy.</p>
            </div>
            <div className="border-l-4 border-teal-600 pl-4 space-y-2">
              <h3 className="font-semibold text-white">Quality Matters</h3>
              <p className="text-gray-300">Small things done well beat big things done poorly. Every detail counts.</p>
            </div>
          </div>
        </section>

        {/* Stats */}
        <section className="grid grid-cols-2 md:grid-cols-4 gap-6 bg-gray-900 p-8 rounded-lg border border-gray-800">
          <div className="space-y-2">
            <div className="text-3xl font-bold text-white">6</div>
            <div className="text-sm text-gray-400">Clean Pages</div>
          </div>
          <div className="space-y-2">
            <div className="text-3xl font-bold text-white">∞</div>
            <div className="text-sm text-gray-400">Possibilities</div>
          </div>
          <div className="space-y-2">
            <div className="text-3xl font-bold text-white">1</div>
            <div className="text-sm text-gray-400">Goal</div>
          </div>
          <div className="space-y-2">
            <div className="text-3xl font-bold text-white">100%</div>
            <div className="text-sm text-gray-400">Handmade</div>
          </div>
        </section>
      </div>
    </Layout>
  );
}
