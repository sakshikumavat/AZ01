import Layout from '../components/Layout';

export default function Services() {
  const services = [
    {
      title: 'Design',
      description: 'Simple, clean, and purposeful design that works. We focus on clarity and usability.',
      icon: '🎨'
    },
    {
      title: 'Development',
      description: 'Small, maintainable code. Fast sites. Built to last. No unnecessary complexity.',
      icon: '⚙️'
    },
    {
      title: 'Consulting',
      description: 'Clear advice without jargon. We help you think through problems and find simple solutions.',
      icon: '💡'
    },
    {
      title: 'Support',
      description: 'When you need help, we\'re here. Quick responses. Friendly solutions. Real support.',
      icon: '🤝'
    }
  ];

  return (
    <Layout>
      <div className="space-y-12 py-12">
        <section className="space-y-4">
          <h1 className="text-4xl font-serif font-bold text-white">Services</h1>
          <p className="text-gray-300 max-w-2xl">We offer straightforward services focused on simplicity, quality, and getting things done right.</p>
        </section>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {services.map((s, i) => (
            <div key={i} className="border border-gray-800 p-6 rounded-lg hover:border-teal-600 hover:bg-gray-900 transition space-y-3">
              <div className="text-4xl">{s.icon}</div>
              <h3 className="text-xl font-semibold text-white">{s.title}</h3>
              <p className="text-gray-300 leading-relaxed">{s.description}</p>
            </div>
          ))}
        </div>

        {/* CTA */}
        <section className="bg-teal-600 text-white p-8 md:p-12 rounded-lg space-y-4">
          <h2 className="text-2xl font-semibold">Ready to Work Together?</h2>
          <p className="text-teal-50">Let's talk about your project. No pressure, no sales pitch — just honest conversation.</p>
          <button className="mt-4 px-6 py-3 bg-white text-teal-600 rounded font-medium hover:bg-gray-200 transition">
            Get in Touch
          </button>
        </section>
      </div>
    </Layout>
  );
}
