import Layout from '../components/Layout';

export default function Home() {
  return (
    <Layout>
      <div className="space-y-16 py-12">
        {/* Hero Section */}
        <section className="space-y-6">
          <div>
            <h1 className="text-5xl md:text-6xl font-serif font-bold text-white mb-4 leading-tight">
              Agenticzone.....
            </h1>
            <p className="text-xl text-gray-300 max-w-2xl leading-relaxed">
              A simple, minimal website built with care. Clean design, readable content, and thoughtful spacing.
            </p>
          </div>
          <button className="mt-6 px-6 py-3 bg-teal-600 text-white rounded text-sm font-medium hover:bg-teal-700 transition">
            Get Started
          </button>
        </section>

        {/* Features */}
        <section className="space-y-8">
          <h2 className="text-2xl font-semibold text-white">What You'll Find</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="space-y-2">
              <div className="text-3xl">📝</div>
              <h3 className="font-semibold text-white">Clear Content</h3>
              <p className="text-gray-400 text-sm">Written with purpose. Easy to scan. No fluff.</p>
            </div>
            <div className="space-y-2">
              <div className="text-3xl">🎨</div>
              <h3 className="font-semibold text-white">Simple Design</h3>
              <p className="text-gray-400 text-sm">Minimal, calm, and intentional. Beauty in simplicity.</p>
            </div>
            <div className="space-y-2">
              <div className="text-3xl">⚡</div>
              <h3 className="font-semibold text-white">Fast & Smooth</h3>
              <p className="text-gray-400 text-sm">No bloat. Everything loads quick. Works everywhere.</p>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="bg-gray-900 p-8 md:p-12 rounded-lg space-y-4 border border-gray-800">
          <h2 className="text-2xl font-semibold text-white">Explore the Pages</h2>
          <p className="text-gray-300">Use the navigation at the top to discover more. Each page is simple, focused, and easy to understand.</p>
        </section>
      </div>
    </Layout>
  );
}
