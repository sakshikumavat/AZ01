export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="mt-16 border-t border-gray-800 bg-black">
      <div className="max-w-3xl mx-auto px-4 py-8 text-center text-sm text-gray-400">
        <p className="mb-2">&copy; {currentYear} Ecommerce</p>
        <p>
          <a href="/" className="mr-4 hover:text-teal-300 hover:underline">Home</a>
          <a href="/contact" className="mr-4 hover:text-teal-300 hover:underline">Contact</a>
          <a href="/about" className="hover:text-teal-300 hover:underline">About</a>
        </p>
      </div>
    </footer>
  );
}
