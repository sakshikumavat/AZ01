import Header from './Header';
import Footer from './Footer';

export default function Layout({ children }) {
  return (
    <div className="min-h-screen flex flex-col font-serif text-white bg-black">
      <Header />
      <main className="flex-grow">
        <div className="max-w-3xl mx-auto px-4 py-8">
          {children}
        </div>
      </main>
      <Footer />
    </div>
  );
}
