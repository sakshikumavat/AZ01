import { Link } from 'react-router-dom';

export default function Header() {
  return (
    <header className="border-b border-teal-700 bg-black">
      <nav className="max-w-3xl mx-auto px-4 py-4 flex items-center justify-between">
        <Link to="/" className="text-xl font-serif font-semibold text-teal-400">
          Ecommerce
        </Link>
        <div className="space-x-4">
          <Link to="/" className="text-sm text-teal-300 hover:text-teal-200 hover:underline">Home</Link>
          <Link to="/about" className="text-sm text-teal-300 hover:text-teal-200 hover:underline">About</Link>
          <Link to="/services" className="text-sm text-teal-300 hover:text-teal-200 hover:underline">Services</Link>
          <Link to="/projects" className="text-sm text-teal-300 hover:text-teal-200 hover:underline">Projects</Link>
          <Link to="/blog" className="text-sm text-teal-300 hover:text-teal-200 hover:underline">Blog</Link>
          <Link to="/contact" className="text-sm text-teal-300 hover:text-teal-200 hover:underline">Contact</Link>
        </div>
      </nav>
    </header>
  );
}
